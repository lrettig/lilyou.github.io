$('document').ready(function(){

  // Set the body's background color to equal the pageLoadData object's backgroundColor property

  // In .elem-1 set the background image, and the content inside .elem-1__title and .elem-1_date

  // In .elem-2 set the background image, and the content inside .elem-2__title and .elem-2_date

  // In .elem-3 set the background image, and the content inside .elem-3__title and .elem-3_date

  // In .elem-4 set the background image, and the content inside .elem-4__title and .elem-4_date

  // Put the cteated at date from our data object into the footer's h1

})

